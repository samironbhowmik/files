import './App.css';
import Temperature from './temperature/temperature';

function App() {
  return (
    <div className="App">
      <Temperature/>
    </div>
  );
}

export default App;
