import Portfolio from "./components/portfolio";


function App() {
  return (
    <div className="App">
        <Portfolio/>
    </div>
  );
}

export default App;
