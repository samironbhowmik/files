import { Carousel } from 'react-responsive-carousel';
import './App.css';
import Slider from './carousel/carousel';

function App() {
  return (
    <div className="App">
      <Slider/>
    </div>
  );
}

export default App;
